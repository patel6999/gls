<?php
// ---- Database settings (XAMPP default) ----
const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_PASS = '';
const DB_NAME = 'visitor_db';

const UPLOAD_DIR = __DIR__ . '/uploads/';

date_default_timezone_set('Asia/Kolkata');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

function db(): mysqli {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        $conn->set_charset('utf8mb4');
        $conn->query("SET time_zone = '+05:30'");
    }
    return $conn;
}

function json_out(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

function read_json(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

// Base64 selfie (data URL) ko validate karke uploads/ me save karta hai.
// Success par file ka naam return karta hai, fail par null.
function save_selfie(string $dataUrl): ?string {
    if (!preg_match('#^data:image/(jpeg|jpg|png);base64,#', $dataUrl)) {
        return null;
    }
    $bin = base64_decode(substr($dataUrl, strpos($dataUrl, ',') + 1), true);
    if ($bin === false || strlen($bin) > 3 * 1024 * 1024) {
        return null;
    }
    $info = @getimagesizefromstring($bin);
    if (!$info) {
        return null;
    }
    $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png'][$info['mime']] ?? null;
    if ($ext === null) {
        return null;
    }
    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0775, true);
    }
    $name = date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
    if (file_put_contents(UPLOAD_DIR . $name, $bin) === false) {
        return null;
    }
    return $name;
}
