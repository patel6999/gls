<?php $prefill = htmlspecialchars($_GET['name'] ?? '', ENT_QUOTES); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <div class="wrap">
    <div class="card">
      <section id="form">
        <h2>Login</h2>
        <label class="field"><span>Name</span>
          <input type="text" id="name" value="<?= $prefill ?>" placeholder="Registered naam likho" autocomplete="name">
        </label>

        <div class="selfie-box">
          <video id="video" autoplay playsinline muted></video>
          <img id="preview" alt="selfie" hidden>
        </div>
        <p class="muted" id="camMsg"></p>
        <button class="btn" id="btnCapture" type="button">Selfie lo</button>
        <label class="btn" id="fallback" hidden>Front camera kholo
          <input type="file" id="fileInput" accept="image/*" capture="user" hidden>
        </label>
        <button class="btn ghost" id="btnRetake" type="button" hidden>Dobara lo</button>

        <button class="btn" id="btnLogin" type="button">Login</button>
        <p class="msg err" id="msg"></p>
        <a class="btn ghost" href="register.php">Naye ho? Register karo</a>
      </section>

      <section id="done" class="center" hidden>
        <div class="tick">&#10003;</div>
        <h2>Login ho gaya</h2>
        <p class="muted" id="doneMsg"></p>
      </section>
    </div>
  </div>

  <script src="assets/selfie.js"></script>
  <script>
    const $ = id => document.getElementById(id);
    Selfie.init();

    $('btnLogin').onclick = async () => {
      const name = $('name').value.trim();
      const selfie = Selfie.get();
      $('msg').className = 'msg err';
      if (name.length < 2) return $('msg').textContent = 'Naam likho.';
      if (!selfie) return $('msg').textContent = 'Pehle selfie lo.';
      $('msg').textContent = '';
      $('btnLogin').disabled = true;
      $('btnLogin').textContent = 'Checking...';
      try {
        const res = await fetch('api_login.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, selfie })
        });
        const data = await res.json();
        if (data.ok) {
          Selfie.stop();
          $('doneMsg').textContent = data.message;
          $('form').hidden = true;
          $('done').hidden = false;
        } else {
          $('msg').textContent = data.message;
          if (data.code === 'not_found') {
            setTimeout(() => location.href = 'register.php?name=' + encodeURIComponent(name), 1800);
          }
        }
      } catch (e) {
        $('msg').textContent = 'Network error, dobara try karo.';
      }
      $('btnLogin').disabled = false;
      $('btnLogin').textContent = 'Login';
    };
  </script>
</body>
</html>
