CREATE DATABASE IF NOT EXISTS visitor_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE visitor_db;

-- Ek visitor ek hi baar register hota hai (mobile number unique)
CREATE TABLE IF NOT EXISTS visitors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  mobile VARCHAR(15) NOT NULL UNIQUE,
  selfie VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_name (name)
);

-- Har baar aane par (register ya login) ek visit record banta hai
CREATE TABLE IF NOT EXISTS visits (
  id INT AUTO_INCREMENT PRIMARY KEY,
  visitor_id INT NOT NULL,
  selfie VARCHAR(255) NOT NULL,
  type ENUM('register','login') NOT NULL,
  visited_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_visited (visited_at),
  FOREIGN KEY (visitor_id) REFERENCES visitors(id) ON DELETE CASCADE
);
