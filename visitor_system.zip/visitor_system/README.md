# Visitor QR Entry System (HTML, CSS, JS, PHP, MySQL)

## Flow
1. Gate par QR code lagega (`qr.php` se banta hai). Visitor mobile se scan karta hai -> `index.php`.
2. **Register** (pehli baar): Name + Mobile -> Next -> live selfie -> Save -> MySQL me save.
3. **Login** (dobara): sirf Name + selfie. Naam mila to visit save hoti hai, nahi mila to Register page par bhej dete hain.
4. Har floor ki display (`floor.php?floor=1`, `2`, `3`) par visitor ka naam, number, selfie aur time live dikhta hai (har 3 second me auto-refresh).

## Setup (XAMPP)
1. Is folder ko `C:\xampp\htdocs\visitor_system` me copy karo.
2. XAMPP me **Apache** aur **MySQL** start karo.
3. phpMyAdmin (`http://localhost/phpmyadmin`) me `database.sql` import karo.
4. Agar MySQL password hai to `config.php` me change karo.
5. Laptop ka IP nikalo (`ipconfig` -> IPv4, jaise `192.168.1.5`).
6. Laptop par `http://localhost/visitor_system/qr.php` kholo, URL box me `http://192.168.1.5/visitor_system/index.php` daalo, **QR banao** dabao.
7. Mobile ko **same WiFi** par rakho aur QR scan karo.
8. Floor displays par `http://192.168.1.5/visitor_system/floor.php?floor=1` (2, 3) kholo.

## Camera ke baare me
Mobile browsers live camera (getUserMedia) sirf **HTTPS** ya localhost par dete hain. Local WiFi (HTTP) par code apne aap
"Front camera kholo" button dikha deta hai, jo phone ka front camera kholta hai. Selfie phir bhi live hi leni padti hai.
Agar sidha live preview chahiye to ngrok jaisa HTTPS tunnel use karo (`ngrok http 80`) aur QR me wo URL daalo.

## Files
| File | Kaam |
|---|---|
| `database.sql` | Tables: `visitors`, `visits` |
| `config.php` | DB connection + selfie save helper |
| `index.php` | Login / Register choice |
| `register.php` + `api_register.php` | Registration (2 steps) |
| `login.php` + `api_login.php` | Login (name + selfie) |
| `floor.php` + `api_latest.php` | Floor display (live) |
| `qr.php` | QR code generator |
| `assets/` | CSS + selfie camera JS |
| `uploads/` | Saved selfies |
