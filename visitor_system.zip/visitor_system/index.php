<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Visitor Entry</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <div class="wrap">
    <div class="card center">
      <h1>Welcome</h1>
      <p class="muted">Ghar me entry ke liye login ya register karo.</p>
      <a class="btn" href="login.php">Login</a>
      <a class="btn ghost" href="register.php">Register (pehli baar)</a>
    </div>
  </div>
</body>
</html>
