<?php
$floor = (int)($_GET['floor'] ?? 1);
if ($floor < 1 || $floor > 3) { $floor = 1; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Floor <?= $floor ?> Display</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body class="display">
  <div class="display-head">
    <h1>Floor <?= $floor ?> &mdash; Visitors Niche Aaye Hain</h1>
    <div>
      <span class="pill" id="status">connecting...</span>
      <span class="pill" id="clock"></span>
      <button class="pill" id="soundBtn" style="background:none;cursor:pointer">Sound: off</button>
    </div>
  </div>
  <div class="grid" id="grid"></div>

  <script>
    const grid = document.getElementById('grid');
    const statusEl = document.getElementById('status');
    let lastId = 0, first = true, soundOn = false, audioCtx = null;

    const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

    function beep() {
      if (!soundOn || !audioCtx) return;
      const o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.connect(g); g.connect(audioCtx.destination);
      o.frequency.value = 880; g.gain.value = 0.2;
      o.start(); o.stop(audioCtx.currentTime + 0.35);
    }

    document.getElementById('soundBtn').onclick = e => {
      soundOn = !soundOn;
      if (soundOn && !audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      e.target.textContent = 'Sound: ' + (soundOn ? 'on' : 'off');
      if (soundOn) beep();
    };

    function card(v, fresh) {
      const t = new Date(v.visited_at.replace(' ', 'T'))
        .toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      return `<div class="vcard ${fresh ? 'fresh' : ''}">
        <img src="uploads/${esc(v.selfie)}" alt="${esc(v.name)}">
        <div class="info">
          <div class="nm">${esc(v.name)}</div>
          <div class="mb">${esc(v.mobile)}</div>
          <span class="badge ${v.type}">${v.type === 'register' ? 'Naya visitor' : 'Wapas aaya'}</span>
          <span class="tm">${t}</span>
        </div>
      </div>`;
    }

    async function poll() {
      try {
        const r = await fetch('api_latest.php', { cache: 'no-store' });
        const d = await r.json();
        if (!d.ok) throw new Error(d.message);
        const maxId = d.visits.length ? d.visits[0].id : 0;
        const hasNew = !first && maxId > lastId;
        grid.innerHTML = d.visits.map(v => card(v, !first && v.id > lastId)).join('')
          || '<p class="muted">Abhi tak koi visitor nahi aaya.</p>';
        if (hasNew) beep();
        lastId = Math.max(lastId, maxId);
        first = false;
        statusEl.textContent = 'live';
        statusEl.className = 'pill live';
      } catch (e) {
        statusEl.textContent = 'offline';
        statusEl.className = 'pill off';
      }
    }

    setInterval(() => {
      document.getElementById('clock').textContent = new Date().toLocaleTimeString();
    }, 1000);
    setInterval(poll, 3000);
    poll();
  </script>
</body>
</html>
