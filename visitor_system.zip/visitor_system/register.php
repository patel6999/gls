<?php $prefill = htmlspecialchars($_GET['name'] ?? '', ENT_QUOTES); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Register</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <div class="wrap">
    <div class="card">
      <div class="steps">
        <span class="dot active" id="d1">1</span><span class="line"></span><span class="dot" id="d2">2</span>
      </div>

      <!-- Step 1: Name + Number -->
      <section id="step1">
        <h2>Register</h2>
        <label class="field"><span>Name</span>
          <input type="text" id="name" value="<?= $prefill ?>" placeholder="Apna naam likho" autocomplete="name">
        </label>
        <label class="field"><span>Mobile number</span>
          <input type="tel" id="mobile" placeholder="10 digit number" maxlength="10" inputmode="numeric" autocomplete="tel">
        </label>
        <button class="btn" id="btnNext" type="button">Next</button>
        <p class="msg err" id="msg1"></p>
        <a class="btn ghost" href="index.php">Back</a>
      </section>

      <!-- Step 2: Live selfie -->
      <section id="step2" hidden>
        <h2>Apni selfie lo</h2>
        <div class="selfie-box">
          <video id="video" autoplay playsinline muted></video>
          <img id="preview" alt="selfie" hidden>
        </div>
        <p class="muted" id="camMsg"></p>
        <button class="btn" id="btnCapture" type="button">Selfie lo</button>
        <label class="btn" id="fallback" hidden>Front camera kholo
          <input type="file" id="fileInput" accept="image/*" capture="user" hidden>
        </label>
        <button class="btn ghost" id="btnRetake" type="button" hidden>Dobara lo</button>
        <button class="btn" id="btnSave" type="button">Save</button>
        <p class="msg err" id="msg2"></p>
      </section>

      <!-- Done -->
      <section id="done" class="center" hidden>
        <div class="tick">&#10003;</div>
        <h2>Registration ho gaya</h2>
        <p class="muted" id="doneMsg"></p>
      </section>
    </div>
  </div>

  <script src="assets/selfie.js"></script>
  <script>
    const $ = id => document.getElementById(id);
    const show = id => ['step1', 'step2', 'done'].forEach(s => $(s).hidden = (s !== id));

    $('btnNext').onclick = async () => {
      const name = $('name').value.trim();
      const mobile = $('mobile').value.trim();
      if (name.length < 2) return $('msg1').textContent = 'Naam sahi se likho.';
      if (!/^[6-9]\d{9}$/.test(mobile)) return $('msg1').textContent = '10 digit ka sahi mobile number likho.';
      $('msg1').textContent = '';
      $('d1').classList.add('done');
      $('d2').classList.add('active');
      show('step2');
      await Selfie.init();
    };

    $('btnSave').onclick = async () => {
      const selfie = Selfie.get();
      if (!selfie) return $('msg2').textContent = 'Pehle selfie lo.';
      $('msg2').textContent = '';
      $('btnSave').disabled = true;
      $('btnSave').textContent = 'Saving...';
      try {
        const res = await fetch('api_register.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: $('name').value.trim(), mobile: $('mobile').value.trim(), selfie })
        });
        const data = await res.json();
        if (data.ok) {
          Selfie.stop();
          $('doneMsg').textContent = data.message;
          show('done');
        } else {
          $('msg2').textContent = data.message;
          if (data.code === 'exists') {
            setTimeout(() => location.href = 'login.php?name=' + encodeURIComponent($('name').value.trim()), 1800);
          }
        }
      } catch (e) {
        $('msg2').textContent = 'Network error, dobara try karo.';
      }
      $('btnSave').disabled = false;
      $('btnSave').textContent = 'Save';
    };
  </script>
</body>
</html>
