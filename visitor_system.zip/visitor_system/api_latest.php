<?php
require __DIR__ . '/config.php';

try {
    $sql = "SELECT v.id, vi.name, vi.mobile, v.selfie, v.type, v.visited_at
            FROM visits v
            JOIN visitors vi ON vi.id = v.visitor_id
            WHERE DATE(v.visited_at) = CURDATE()
            ORDER BY v.id DESC
            LIMIT 12";
    $rows = db()->query($sql)->fetch_all(MYSQLI_ASSOC);
    foreach ($rows as &$r) {
        $r['id'] = (int)$r['id'];
    }
    json_out(['ok' => true, 'visits' => $rows]);
} catch (Throwable $e) {
    json_out(['ok' => false, 'message' => $e->getMessage()], 500);
}
