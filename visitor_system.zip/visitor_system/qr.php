<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Entry QR Code</title>
  <link rel="stylesheet" href="assets/style.css">
  <style>
    #qr { background: #fff; padding: 14px; border-radius: 12px; display: inline-block; margin: 16px 0; }
    #qr img, #qr canvas { display: block; }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card center">
      <h1>Entry QR Code</h1>
      <p class="muted">Isse print karke ghar ke gate par lagao. Visitor mobile se scan karega.</p>

      <label class="field" style="text-align:left; margin-top:14px">
        <span>Visitor page ka URL (laptop ka IP daalo, localhost nahi)</span>
        <input type="text" id="url">
      </label>
      <button class="btn" id="gen" type="button">QR banao</button>

      <div id="qr"></div>

      <div class="floor-links">
        <a class="btn ghost" href="floor.php?floor=1" target="_blank">Floor 1</a>
        <a class="btn ghost" href="floor.php?floor=2" target="_blank">Floor 2</a>
        <a class="btn ghost" href="floor.php?floor=3" target="_blank">Floor 3</a>
      </div>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
  <script>
    const urlInput = document.getElementById('url');
    urlInput.value = location.href.replace('qr.php', 'index.php');
    let qr = null;
    function make() {
      const box = document.getElementById('qr');
      box.innerHTML = '';
      qr = new QRCode(box, { text: urlInput.value.trim(), width: 240, height: 240 });
    }
    document.getElementById('gen').onclick = make;
    make();
  </script>
</body>
</html>
