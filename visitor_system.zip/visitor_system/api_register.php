<?php
require __DIR__ . '/config.php';

try {
    $in     = read_json();
    $name   = trim($in['name'] ?? '');
    $mobile = preg_replace('/\D/', '', $in['mobile'] ?? '');
    $selfie = $in['selfie'] ?? '';

    if (mb_strlen($name) < 2 || mb_strlen($name) > 100) {
        json_out(['ok' => false, 'message' => 'Naam sahi se likho.'], 422);
    }
    if (!preg_match('/^[6-9]\d{9}$/', $mobile)) {
        json_out(['ok' => false, 'message' => '10 digit ka sahi mobile number likho.'], 422);
    }

    $db = db();

    $st = $db->prepare('SELECT id FROM visitors WHERE mobile = ?');
    $st->bind_param('s', $mobile);
    $st->execute();
    if ($st->get_result()->num_rows > 0) {
        json_out(['ok' => false, 'code' => 'exists',
                  'message' => 'Ye number pehle se registered hai. Login karo.'], 409);
    }

    $file = save_selfie($selfie);
    if ($file === null) {
        json_out(['ok' => false, 'message' => 'Selfie sahi nahi hai, dobara lo.'], 422);
    }

    $st = $db->prepare('INSERT INTO visitors (name, mobile, selfie) VALUES (?, ?, ?)');
    $st->bind_param('sss', $name, $mobile, $file);
    $st->execute();
    $vid = $db->insert_id;

    $st = $db->prepare("INSERT INTO visits (visitor_id, selfie, type) VALUES (?, ?, 'register')");
    $st->bind_param('is', $vid, $file);
    $st->execute();

    json_out(['ok' => true, 'message' => 'Registration ho gaya! Owner ko dikha diya gaya hai.', 'name' => $name]);
} catch (Throwable $e) {
    json_out(['ok' => false, 'message' => 'Server error: ' . $e->getMessage()], 500);
}
