/* Selfie helper
   - Pehle front camera se LIVE preview kholta hai (getUserMedia).
   - Agar browser allow na kare (jaise HTTP par), to phone ka front camera
     <input capture="user"> se khulta hai, taaki selfie phir bhi live le sako. */
const Selfie = (() => {
  let stream = null;
  let dataUrl = null;
  const $ = id => document.getElementById(id);

  function resize(source, w, h) {
    const scale = Math.min(1, 480 / Math.max(w, h));
    const c = document.createElement('canvas');
    c.width = Math.round(w * scale);
    c.height = Math.round(h * scale);
    c.getContext('2d').drawImage(source, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', 0.8);
  }

  function stopStream() {
    if (stream) {
      stream.getTracks().forEach(t => t.stop());
      stream = null;
    }
  }

  async function startCamera() {
    dataUrl = null;
    $('preview').hidden = true;
    $('btnRetake').hidden = true;
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('unsupported');
      }
      stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false });
      const v = $('video');
      v.srcObject = stream;
      await v.play();
      v.hidden = false;
      $('btnCapture').hidden = false;
      $('fallback').hidden = true;
      $('camMsg').textContent = '';
    } catch (e) {
      $('video').hidden = true;
      $('btnCapture').hidden = true;
      $('fallback').hidden = false;
      $('camMsg').textContent = 'Live camera yahan allow nahi hua. Neeche button se front camera khol ke selfie lo.';
    }
  }

  function setPreview(url) {
    dataUrl = url;
    $('preview').src = url;
    $('preview').hidden = false;
    $('video').hidden = true;
    $('btnCapture').hidden = true;
    $('fallback').hidden = true;
    $('btnRetake').hidden = false;
    $('camMsg').textContent = '';
  }

  function init() {
    $('btnCapture').onclick = () => {
      const v = $('video');
      if (!v.videoWidth) return;
      setPreview(resize(v, v.videoWidth, v.videoHeight));
      stopStream();
    };
    $('btnRetake').onclick = () => startCamera();
    $('fileInput').onchange = e => {
      const f = e.target.files[0];
      if (!f) return;
      const img = new Image();
      const url = URL.createObjectURL(f);
      img.onload = () => {
        setPreview(resize(img, img.naturalWidth, img.naturalHeight));
        URL.revokeObjectURL(url);
      };
      img.src = url;
      e.target.value = '';
    };
    return startCamera();
  }

  return { init, get: () => dataUrl, stop: stopStream };
})();
