<?php
require __DIR__ . '/config.php';

try {
    $in     = read_json();
    $name   = trim($in['name'] ?? '');
    $selfie = $in['selfie'] ?? '';

    if (mb_strlen($name) < 2) {
        json_out(['ok' => false, 'message' => 'Naam likho.'], 422);
    }

    $db = db();

    // Naam se registered visitor dhundho (latest wala)
    $st = $db->prepare('SELECT id, name FROM visitors WHERE LOWER(name) = LOWER(?) ORDER BY id DESC LIMIT 1');
    $st->bind_param('s', $name);
    $st->execute();
    $visitor = $st->get_result()->fetch_assoc();

    if (!$visitor) {
        json_out(['ok' => false, 'code' => 'not_found',
                  'message' => 'Aap registered nahi ho. Pehle register karo.'], 404);
    }

    $file = save_selfie($selfie);
    if ($file === null) {
        json_out(['ok' => false, 'message' => 'Selfie sahi nahi hai, dobara lo.'], 422);
    }

    $st = $db->prepare("INSERT INTO visits (visitor_id, selfie, type) VALUES (?, ?, 'login')");
    $st->bind_param('is', $visitor['id'], $file);
    $st->execute();

    json_out(['ok' => true, 'message' => 'Welcome back, ' . $visitor['name'] . '! Owner ko dikha diya gaya hai.']);
} catch (Throwable $e) {
    json_out(['ok' => false, 'message' => 'Server error: ' . $e->getMessage()], 500);
}
